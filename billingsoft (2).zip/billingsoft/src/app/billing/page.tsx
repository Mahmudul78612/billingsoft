"use client";

import { useState, useEffect } from "react";
import { db } from "@/lib/firebase";
import { collection, addDoc, getDocs, Timestamp } from "firebase/firestore";
import { BarcodeScanner } from "@/components/BarcodeScanner";
import TextField from "@mui/material/TextField";
import IconButton from "@mui/material/IconButton";
import Button from "@mui/material/Button";
import Paper from "@mui/material/Paper";
import Divider from "@mui/material/Divider";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import PersonIcon from "@mui/icons-material/Person";
import CurrencyRupeeIcon from "@mui/icons-material/CurrencyRupee";
import QrCodeScannerIcon from "@mui/icons-material/QrCodeScanner";
import DeleteIcon from "@mui/icons-material/Delete";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import Script from "next/script";

type Product = {
  id: string;
  name: string;
  sellingPrice: number;
  discountPrice?: number;
  quantity: number;
  unit: string;
  barcode: string;
};

type CartItem = Product & { cartQty: number };
type PaymentMethod = "cash" | "upi";

export default function BillingPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customerPhone, setCustomerPhone] = useState("");
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [razorpayLoaded, setRazorpayLoaded] = useState(false);

  useEffect(() => {
    if (!search.trim()) {
      setProducts([]);
      return;
    }
    const fetchProducts = async () => {
      const querySnapshot = await getDocs(collection(db, "products"));
      const allProducts = querySnapshot.docs.map(docSnap => {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          name: data.name || "",
          sellingPrice: data.sellingPrice || 0,
          discountPrice: data.discountPrice || 0,
          quantity: data.quantity || 0,
          unit: data.unit || "pcs",
          barcode: data.barcode || "",
        };
      });
      setProducts(
        allProducts.filter(
          p =>
            p.name.toLowerCase().includes(search.toLowerCase()) ||
            (p.barcode && p.barcode.includes(search))
        )
      );
    };
    fetchProducts();
  }, [search]);

  const handleAddToCart = (product: Product) => {
    setCart(prev => {
      const exists = prev.find(item => item.id === product.id);
      if (exists) {
        return prev.map(item =>
          item.id === product.id ? { ...item, cartQty: item.cartQty + 1 } : item
        );
      }
      return [...prev, { ...product, cartQty: 1 }];
    });
  };

  const handleCartQty = (id: string, qty: number) => {
    setCart(prev => prev.map(item => item.id === id ? { ...item, cartQty: qty } : item));
  };

  const handleRemove = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const subtotal = cart.reduce((sum, item) => sum + item.sellingPrice * item.cartQty, 0);
  const discount = cart.reduce((sum, item) => sum + (item.discountPrice || 0) * item.cartQty, 0);
  const total = subtotal - discount;

  // Razorpay handler
  const handleUPIPayment = () => {
    if (!razorpayLoaded) {
      setError("Razorpay SDK not loaded. Please try again.");
      return;
    }
    const options = {
      key: "rzp_test_dz2faDYKKJLI6i",
      amount: total * 100, // in paise
      currency: "INR",
      name: "Deepu Store",
      description: `Invoice for ₹${total}`,
      handler: function (response: unknown) {
        if (
          response &&
          typeof response === "object" &&
          "razorpay_payment_id" in response &&
          typeof (response as { razorpay_payment_id?: unknown }).razorpay_payment_id === "string"
        ) {
          handleCheckout("upi", (response as { razorpay_payment_id: string }).razorpay_payment_id);
        } else {
          setError("Payment failed or invalid response.");
        }
      },
      prefill: {
        contact: customerPhone,
      },
      theme: { color: "#6366f1" },
      method: { upi: true, card: false, netbanking: false, wallet: false },
    };
    // @ts-expect-error: Razorpay window type is not defined, but this is required for SDK usage
    const rzp = new window.Razorpay(options);
    rzp.open();
  };

  // Modified checkout to accept payment method
  const handleCheckout = async (method: PaymentMethod = "cash", paymentId?: string) => {
    if (!customerPhone || cart.length === 0) {
      setError("Enter customer phone and add products to cart.");
      return;
    }
    setLoading(true);
    setError("");
    setSuccess("");
    try {
      const billRef = await addDoc(collection(db, "bills"), {
        customerPhone,
        items: cart,
        subtotal,
        discount,
        total,
        createdAt: Timestamp.now(),
        paymentMethod: method,
        paymentId: paymentId || null,
      });
      setSuccess("Bill saved successfully!");
      // PDF GENERATION
      const doc = new jsPDF();
      // Store Header
      doc.setFontSize(20);
      doc.text("Deepu Store", 14, 16);
      doc.setFontSize(11);
      doc.text("Address: panikhaity", 14, 24);
      doc.text("Phone: 9387029304", 14, 30);
      // Invoice Title
      doc.setFontSize(16);
      doc.text("INVOICE", 150, 16, { align: "right" });
      doc.setFontSize(12);
      doc.text(`Bill ID: ${billRef.id}`, 150, 24, { align: "right" });
      doc.text(`Date: ${new Date().toLocaleString()}`, 150, 30, { align: "right" });
      doc.text(`Customer Phone: ${customerPhone}`, 150, 36, { align: "right" });
      doc.text(`Payment: ${method === "upi" ? "UPI" : "Cash"}`, 150, 42, { align: "right" });
      // Table
      const tableResult = autoTable(doc, {
        startY: 48,
        head: [["Product", "Qty", "Price", "Discount", "Total"]],
        body: cart.map(item => [
          item.name,
          item.cartQty,
          `₹${item.sellingPrice}`,
          `₹${item.discountPrice || 0}`,
          `₹${item.sellingPrice * item.cartQty - (item.discountPrice || 0) * item.cartQty}`
        ]),
      }) as { finalY?: number };
      const finalY = typeof tableResult === 'object' && tableResult && 'finalY' in tableResult && typeof tableResult.finalY === 'number'
        ? tableResult.finalY
        : 48 + cart.length * 10;
      doc.text(`Subtotal: ₹${subtotal}`, 14, finalY + 10);
      doc.text(`Discount: ₹${discount}`, 14, finalY + 18);
      doc.text(`Total: ₹${total}`, 14, finalY + 26);
      doc.save(`invoice_${billRef.id}.pdf`);
      setCart([]);
      setCustomerPhone("");
    } catch {
      setError("Failed to save bill.");
    } finally {
      setLoading(false);
    }
  };

  const handleScan = (barcode: string) => {
    setSearch(barcode);
    setShowScanner(false);
  };

  useEffect(() => {
    // Fallback: If Razorpay is already loaded (e.g., from cache or previous navigation), set razorpayLoaded
    if (typeof window !== "undefined" && (window as unknown as { Razorpay?: unknown }).Razorpay) {
      setRazorpayLoaded(true);
    }
  }, []);

  return (
    <Paper elevation={3} className="max-w-4xl mx-auto mt-8 p-1 rounded-2xl bg-gradient-to-br from-[#e0e7ff] via-[#f0abfc] to-[#a5b4fc] shadow-xl border border-blue-100">
      <div className="bg-white/80 rounded-2xl p-4 backdrop-blur-md">
        <Script
          src="https://checkout.razorpay.com/v1/checkout.js"
          onLoad={() => setRazorpayLoaded(true)}
        />
        <h1 className="text-3xl font-bold mb-8 flex items-center gap-3 text-blue-800 drop-shadow-lg">
          <ShoppingCartIcon className="text-blue-500" fontSize="large" /> Billing
        </h1>
        <div className="flex flex-col md:flex-row gap-8 mb-8">
          <Paper elevation={1} className="flex-1 rounded-2xl p-6 bg-white/90 shadow-md">
            <div className="flex gap-2 mb-4 items-center">
              <QrCodeScannerIcon className="text-gray-400" />
              <TextField
                variant="outlined"
                size="small"
                fullWidth
                placeholder="Search product by name or barcode"
                value={search}
                onChange={e => setSearch(e.target.value)}
                InputProps={{ style: { borderRadius: 12 } }}
              />
              <Button
                variant={showScanner ? "contained" : "outlined"}
                color={showScanner ? "error" : "success"}
                onClick={() => setShowScanner(v => !v)}
                style={{ borderRadius: 12, minWidth: 120 }}
              >
                {showScanner ? "Close Scanner" : "Scan Barcode"}
              </Button>
            </div>
            {showScanner && (
              <BarcodeScanner
                onScan={handleScan}
                onClose={() => setShowScanner(false)}
              />
            )}
            <Divider className="my-2" />
            <div className="max-h-56 overflow-y-auto border rounded bg-gray-50 mt-2">
              {products.length > 0 ? (
                products.map(product => (
                  <div
                    key={product.id}
                    className="flex justify-between items-center px-3 py-2 border-b hover:bg-blue-100 cursor-pointer transition-colors"
                    onClick={() => handleAddToCart(product)}
                  >
                    <span className="flex items-center gap-2 text-gray-700">
                      <QrCodeScannerIcon className="text-gray-400" fontSize="small" /> {product.name} <span className="text-xs text-gray-400">({product.unit})</span>
                    </span>
                    <span className="font-semibold text-blue-700 flex items-center gap-1"><CurrencyRupeeIcon className="inline text-blue-400" fontSize="small" />{product.sellingPrice}</span>
                  </div>
                ))
              ) : (
                <div className="text-gray-400 p-4 text-center">No products found</div>
              )}
            </div>
          </Paper>
          <Paper elevation={1} className="flex-1 rounded-2xl p-6 bg-white/90 shadow-md">
            <div className="flex items-center gap-2 mb-4">
              <PersonIcon className="text-gray-400" />
              <TextField
                variant="outlined"
                size="small"
                fullWidth
                placeholder="Customer Phone"
                value={customerPhone}
                onChange={e => setCustomerPhone(e.target.value)}
                InputProps={{ style: { borderRadius: 12 } }}
              />
            </div>
            <Paper elevation={0} className="bg-blue-50 rounded-xl shadow p-2 mb-4">
              <h2 className="font-semibold mb-1 text-blue-700 flex items-center gap-2 text-base"><ShoppingCartIcon className="text-blue-400" fontSize="small" /> Cart</h2>
              {cart.length === 0 ? (
                <div className="text-gray-400 text-sm">No products in cart</div>
              ) : (
                <div className="h-[200px] overflow-y-auto rounded border border-blue-100 bg-white scrollbar-thin scrollbar-thumb-blue-200 scrollbar-track-blue-50">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-blue-700">
                        <th className="text-left font-medium">Product</th>
                        <th className="font-medium">Qty</th>
                        <th className="font-medium">Price</th>
                        <th className="font-medium">Discount</th>
                        <th className="font-medium">Total</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      {cart.map(item => (
                        <tr key={item.id} className="hover:bg-blue-100 transition-colors">
                          <td className="py-1 pl-2">{item.name}</td>
                          <td className="py-1">
                            <TextField
                              type="number"
                              size="small"
                              inputProps={{ min: 1, style: { fontSize: 11, textAlign: 'center', padding: 2, width: 40, borderRadius: 8 } }}
                              value={item.cartQty}
                              onChange={e => handleCartQty(item.id, Number(e.target.value))}
                            />
                          </td>
                          <td className="py-1"><span className="flex items-center gap-1"><CurrencyRupeeIcon className="inline text-blue-400 text-xs" fontSize="small" />{item.sellingPrice}</span></td>
                          <td className="py-1"><span className="flex items-center gap-1"><CurrencyRupeeIcon className="inline text-blue-400 text-xs" fontSize="small" />{item.discountPrice || 0}</span></td>
                          <td className="py-1"><span className="flex items-center gap-1"><CurrencyRupeeIcon className="inline text-blue-400 text-xs" fontSize="small" />{item.sellingPrice * item.cartQty - (item.discountPrice || 0) * item.cartQty}</span></td>
                          <td className="py-1">
                            <IconButton size="small" color="error" onClick={() => handleRemove(item.id)}>
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              <Divider className="my-2" />
              <div className="mt-2 bg-white rounded shadow p-2 border border-blue-100">
                <div className="flex justify-between mb-1 text-gray-700 text-xs">
                  <span>Subtotal:</span>
                  <span className="flex items-center gap-1"><CurrencyRupeeIcon className="inline text-blue-400 text-xs" fontSize="small" />{subtotal}</span>
                </div>
                <div className="flex justify-between mb-1 text-gray-700 text-xs">
                  <span>Discount:</span>
                  <span className="flex items-center gap-1"><CurrencyRupeeIcon className="inline text-blue-400 text-xs" fontSize="small" />{discount}</span>
                </div>
                <div className="flex justify-between font-bold text-base text-blue-800">
                  <span>Total:</span>
                  <span className="flex items-center gap-1"><CurrencyRupeeIcon className="inline text-blue-500 text-base" fontSize="medium" />{total}</span>
                </div>
              </div>
              {error && <div className="text-red-500 text-xs mt-1">{error}</div>}
              {success && <div className="text-green-600 text-xs mt-1">{success}</div>}
              <div className="flex gap-2 mt-2">
                <Button
                  variant="contained"
                  color="success"
                  onClick={() => handleCheckout("cash")}
                  disabled={loading}
                  style={{ borderRadius: 12 }}
                >
                  Collect Cash
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={handleUPIPayment}
                  disabled={loading || !razorpayLoaded}
                  style={{ borderRadius: 12 }}
                >
                  {!razorpayLoaded ? "Loading UPI…" : "Collect UPI"}
                </Button>
              </div>
            </Paper>
          </Paper>
        </div>
      </div>
    </Paper>
  );
}
