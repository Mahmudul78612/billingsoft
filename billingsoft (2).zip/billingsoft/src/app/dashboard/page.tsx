"use client";
import { useEffect, useState, useMemo } from "react";
import { db } from "@/lib/firebase";
import { collection, getDocs } from "firebase/firestore";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import dynamic from "next/dynamic";

type Bill = {
  total?: number;
  createdAt?: { seconds: number; toDate?: () => Date };
  customerPhone?: string;
};

type Product = {
  name: string;
  quantity?: number;
};

// Dynamically import a wrapper chart component for SSR safety
const SalesTrendsChart = dynamic(() => import("@/components/SalesTrendsChart"), { ssr: false });

// Dashboard page placeholder
export default function DashboardPage() {
  const [stats, setStats] = useState([
    { label: "Total Sales Today", value: "-", color: "bg-blue-100 text-blue-800" },
    { label: "This Week", value: "-", color: "bg-green-100 text-green-800" },
    { label: "This Month", value: "-", color: "bg-purple-100 text-purple-800" },
    { label: "Total Products", value: "-", color: "bg-yellow-100 text-yellow-800" },
    { label: "Low Stock Alerts", value: "-", color: "bg-red-100 text-red-800" },
  ]);
  const [recent, setRecent] = useState<string[]>([]);
  // Prepare sales trends data for the chart
  const [bills, setBills] = useState<Bill[]>([]);

  useEffect(() => {
    async function fetchStats() {
      // Fetch bills
      const billsSnap = await getDocs(collection(db, "bills"));
      const bills: Bill[] = billsSnap.docs.map(doc => doc.data() as Bill);
      // Fetch products
      const productsSnap = await getDocs(collection(db, "products"));
      const products: Product[] = productsSnap.docs.map(doc => doc.data() as Product);
      // Date helpers
      const now = new Date();
      const today = now.toISOString().slice(0, 10);
      const weekStart = new Date(now);
      weekStart.setDate(now.getDate() - now.getDay());
      const weekStartStr = weekStart.toISOString().slice(0, 10);
      const monthStr = now.toISOString().slice(0, 7);
      // Sales calculations
      let todayTotal = 0, weekTotal = 0, monthTotal = 0;
      bills.forEach(bill => {
        let created: Date | null = null;
        if (bill.createdAt && typeof bill.createdAt.toDate === "function") {
          created = bill.createdAt.toDate();
        } else if (bill.createdAt && typeof bill.createdAt.seconds === "number") {
          created = new Date(bill.createdAt.seconds * 1000);
        }
        if (!created) return;
        const billDate = created.toISOString().slice(0, 10);
        const billMonth = created.toISOString().slice(0, 7);
        if (billDate === today) todayTotal += bill.total || 0;
        if (billDate >= weekStartStr && billDate <= today) weekTotal += bill.total || 0;
        if (billMonth === monthStr) monthTotal += bill.total || 0;
      });
      // Low stock
      const lowStock = products.filter((p) => typeof p.quantity === "number" && p.quantity <= 5).length;
      setStats([
        { label: "Total Sales Today", value: `₹${todayTotal}`, color: "bg-blue-100 text-blue-800" },
        { label: "This Week", value: `₹${weekTotal}`, color: "bg-green-100 text-green-800" },
        { label: "This Month", value: `₹${monthTotal}`, color: "bg-purple-100 text-purple-800" },
        { label: "Total Products", value: products.length.toString(), color: "bg-yellow-100 text-yellow-800" },
        { label: "Low Stock Alerts", value: lowStock.toString(), color: "bg-red-100 text-red-800" },
      ]);
      setBills(bills); // Save for chart
      // Recent activity
      const recentBills = bills
        .sort((a, b) => ((b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0)))
        .slice(0, 5)
        .map((bill) => `+ Invoice for ₹${bill.total || 0} (${bill.customerPhone || "No phone"})`);
      setRecent([
        ...recentBills,
        ...products.filter((p) => typeof p.quantity === "number" && p.quantity <= 5).map((p) => `- Low stock: ${p.name} (${p.quantity})`)
      ]);
    }
    fetchStats();
  }, []);

  // Group sales by day for the last 14 days
  const salesData = useMemo(() => {
    const days: { [date: string]: number } = {};
    const now = new Date();
    for (let i = 13; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      const key = d.toISOString().slice(0, 10);
      days[key] = 0;
    }
    bills.forEach(bill => {
      let created: Date | null = null;
      if (bill.createdAt && typeof bill.createdAt.toDate === "function") {
        created = bill.createdAt.toDate();
      } else if (bill.createdAt && typeof bill.createdAt.seconds === "number") {
        created = new Date(bill.createdAt.seconds * 1000);
      }
      if (!created) return;
      const key = created.toISOString().slice(0, 10);
      if (key in days) days[key] += bill.total || 0;
    });
    return Object.entries(days).map(([date, total]) => ({ date, total }));
  }, [bills]);

  return (
    <div className="flex flex-col gap-8 min-h-[100dvh] max-h-[100dvh] overflow-y-auto">
      <h1 className="text-3xl font-bold mb-4">Dashboard</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {stats.map((stat) => (
          <Card key={stat.label} className="shadow-md">
            <CardHeader>
              <CardTitle className="text-base font-medium text-gray-500">{stat.label}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold rounded px-2 py-1 inline-block ${stat.color}`}>{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Sales Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <SalesTrendsChart data={salesData} />
            </div>
          </CardContent>
        </Card>
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="text-gray-600 text-sm space-y-2">
              {recent.length === 0 ? <li>No recent activity</li> : recent.map((r, i) => <li key={i}>{r}</li>)}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
