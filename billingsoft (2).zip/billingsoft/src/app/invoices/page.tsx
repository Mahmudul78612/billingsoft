"use client";

import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import { collection, getDocs, Timestamp, QueryDocumentSnapshot, DocumentData } from "firebase/firestore";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { FaFilePdf, FaRupeeSign } from "react-icons/fa";

// Types
interface BillItem {
  id: string;
  name: string;
  sellingPrice: number;
  discountPrice?: number;
  quantity: number;
  unit: string;
  barcode: string;
  cartQty: number;
}

interface Bill {
  id: string;
  customerPhone: string;
  items: BillItem[];
  subtotal: number;
  discount: number;
  total: number;
  createdAt: Timestamp;
}

// Minimal type for autoTable return value
interface AutoTableResult { finalY: number; }

function parseBill(doc: QueryDocumentSnapshot<DocumentData>): Bill {
  const data = doc.data();
  return {
    id: doc.id,
    customerPhone: data.customerPhone || "",
    items: Array.isArray(data.items)
      ? data.items.map((item: unknown) => {
          // Type guard for BillItem
          if (
            typeof item === "object" &&
            item !== null &&
            "id" in item &&
            "name" in item &&
            "sellingPrice" in item &&
            "quantity" in item &&
            "unit" in item &&
            "barcode" in item &&
            "cartQty" in item
          ) {
            const i = item as Record<string, unknown>;
            return {
              id: String(i.id),
              name: String(i.name),
              sellingPrice: Number(i.sellingPrice),
              discountPrice: i.discountPrice ? Number(i.discountPrice) : undefined,
              quantity: Number(i.quantity),
              unit: String(i.unit),
              barcode: String(i.barcode),
              cartQty: Number(i.cartQty),
            };
          }
          // fallback empty item
          return {
            id: "",
            name: "",
            sellingPrice: 0,
            quantity: 0,
            unit: "",
            barcode: "",
            cartQty: 0,
          };
        })
      : [],
    subtotal: data.subtotal || 0,
    discount: data.discount || 0,
    total: data.total || 0,
    createdAt: data.createdAt instanceof Timestamp ? data.createdAt : Timestamp.now(),
  };
}

export default function InvoicesPage() {
  const [bills, setBills] = useState<Bill[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchBills = async () => {
      setLoading(true);
      setError("");
      try {
        const querySnapshot = await getDocs(collection(db, "bills"));
        const billsData = querySnapshot.docs.map(parseBill);
        // Sort by date desc
        billsData.sort((a, b) => b.createdAt.seconds - a.createdAt.seconds);
        setBills(billsData);
      } catch {
        setError("Failed to fetch invoices.");
      } finally {
        setLoading(false);
      }
    };
    fetchBills();
  }, []);

  const handleDownloadPDF = (bill: Bill) => {
    const doc = new jsPDF();
    // Store Header
    doc.setFontSize(20);
    doc.text("Deepu Store", 14, 16);
    doc.setFontSize(11);
    doc.text("Address: panikhaity", 14, 24);
    doc.text("Phone: 9387029304", 14, 30);
    // Invoice Title
    doc.setFontSize(16);
    doc.text("INVOICE", 150, 16, { align: "right" });
    doc.setFontSize(12);
    doc.text(`Bill ID: ${bill.id}`, 150, 24, { align: "right" });
    doc.text(`Date: ${bill.createdAt.toDate().toLocaleString()}`, 150, 30, { align: "right" });
    doc.text(`Customer Phone: ${bill.customerPhone}`, 150, 36, { align: "right" });
    // Table
    const tableResult = autoTable(doc, {
      startY: 40,
      head: [["Product", "Qty", "Price", "Discount", "Total"]],
      body: bill.items.map(item => [
        item.name,
        item.cartQty,
        `₹${item.sellingPrice}`,
        `₹${item.discountPrice || 0}`,
        `₹${item.sellingPrice * item.cartQty - (item.discountPrice || 0) * item.cartQty}`
      ]),
    }) as { finalY?: number };
    const finalY = typeof tableResult === 'object' && tableResult && 'finalY' in tableResult && typeof tableResult.finalY === 'number'
      ? tableResult.finalY
      : 40 + bill.items.length * 10;
    doc.text(`Subtotal: ₹${bill.subtotal}`, 14, finalY + 10);
    doc.text(`Discount: ₹${bill.discount}`, 14, finalY + 18);
    doc.text(`Total: ₹${bill.total}`, 14, finalY + 26);
    doc.save(`invoice_${bill.id}.pdf`);
  };

  return (
    <div className="max-w-5xl mx-auto mt-8 p-4 bg-gradient-to-br from-blue-50 to-purple-100 rounded-xl shadow-lg">
      <h1 className="text-3xl font-bold mb-8 text-blue-800">Invoices</h1>
      {loading ? (
        <div className="text-gray-500 text-center py-8">Loading invoices...</div>
      ) : error ? (
        <div className="text-red-500 text-center py-8">{error}</div>
      ) : bills.length === 0 ? (
        <div className="text-gray-400 text-center py-8">No invoices found.</div>
      ) : (
        <div className="overflow-x-auto rounded-xl bg-white shadow p-4">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-blue-700 border-b">
                <th className="text-left font-medium py-2">Bill ID</th>
                <th className="text-left font-medium py-2">Date</th>
                <th className="text-left font-medium py-2">Customer Phone</th>
                <th className="text-left font-medium py-2">Items</th>
                <th className="text-left font-medium py-2">Total (₹)</th>
                <th className="py-2"></th>
              </tr>
            </thead>
            <tbody>
              {bills.map(bill => (
                <tr key={bill.id} className="border-b hover:bg-blue-50 transition-colors">
                  <td className="py-2 font-mono text-xs">{bill.id}</td>
                  <td className="py-2">{bill.createdAt.toDate().toLocaleString()}</td>
                  <td className="py-2">{bill.customerPhone}</td>
                  <td className="py-2">
                    <ul className="list-disc pl-4 text-xs">
                      {bill.items.map(item => (
                        <li key={item.id}>{item.name} x {item.cartQty}</li>
                      ))}
                    </ul>
                  </td>
                  <td className="py-2 font-semibold flex items-center gap-1"><FaRupeeSign className="inline text-blue-400 text-xs" />{bill.total}</td>
                  <td className="py-2">
                    <button
                      onClick={() => handleDownloadPDF(bill)}
                      className="bg-gradient-to-r from-blue-600 to-purple-500 text-white px-3 py-1 rounded flex items-center gap-2 hover:from-blue-700 hover:to-purple-600 text-xs shadow"
                    >
                      <FaFilePdf /> PDF
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
