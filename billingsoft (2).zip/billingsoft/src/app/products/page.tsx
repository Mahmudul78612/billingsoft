"use client";

import { useState, useEffect } from "react";
import { db } from "@/lib/firebase";
import { collection, addDoc, getDocs, updateDoc, doc } from "firebase/firestore";
import { BarcodeScanner } from "@/components/BarcodeScanner";

type Product = {
  id?: string;
  name: string;
  purchasePrice: number;
  sellingPrice: number;
  discountPrice?: number;
  quantity: number;
  unit: string;
  barcode: string;
};

type Bill = {
  id?: string;
  items?: BillItem[];
};

type BillItem = {
  id: string;
  name: string;
  sellingPrice: number;
  discountPrice?: number;
  quantity: number;
  unit: string;
  barcode: string;
  cartQty: number;
};

export default function ProductsPage() {
  const [form, setForm] = useState({
    name: "",
    purchasePrice: "",
    sellingPrice: "",
    discountPrice: "",
    quantity: "",
    unit: "pcs",
    barcode: "",
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");
  const [products, setProducts] = useState<Product[]>([]);
  const [editId, setEditId] = useState<string | null>(null);
  const [view, setView] = useState<'add' | 'history'>("add");
  const [showScanner, setShowScanner] = useState(false);

  // Fetch products from Firestore
  useEffect(() => {
    const fetchProducts = async () => {
      const querySnapshot = await getDocs(collection(db, "products"));
      setProducts(
        querySnapshot.docs.map(docSnap => {
          const data = docSnap.data();
          return {
            id: docSnap.id,
            name: data.name || "",
            purchasePrice: data.purchasePrice || 0,
            sellingPrice: data.sellingPrice || 0,
            discountPrice: data.discountPrice || 0,
            quantity: data.quantity || 0,
            unit: data.unit || "pcs",
            barcode: data.barcode || "",
          };
        })
      );
    };
    fetchProducts();
  }, [success]);

  // Fetch bills for product sales history
  const [bills, setBills] = useState<Bill[]>([]);
  useEffect(() => {
    const fetchBills = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "bills"));
        setBills(querySnapshot.docs.map(docSnap => docSnap.data() as Bill));
      } catch {}
    };
    fetchBills();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess("");
    try {
      if (editId) {
        // Update product
        await updateDoc(doc(db, "products", editId), {
          name: form.name,
          purchasePrice: parseFloat(form.purchasePrice),
          sellingPrice: parseFloat(form.sellingPrice),
          discountPrice: parseFloat(form.discountPrice),
          quantity: parseFloat(form.quantity),
          unit: form.unit,
          barcode: form.barcode,
        });
        setSuccess("Product updated successfully!");
        setEditId(null);
      } else {
        // Add new product
        await addDoc(collection(db, "products"), {
          name: form.name,
          purchasePrice: parseFloat(form.purchasePrice),
          sellingPrice: parseFloat(form.sellingPrice),
          discountPrice: parseFloat(form.discountPrice),
          quantity: parseFloat(form.quantity),
          unit: form.unit,
          barcode: form.barcode,
          createdAt: new Date(),
        });
        setSuccess("Product added successfully!");
      }
      setForm({
        name: "",
        purchasePrice: "",
        sellingPrice: "",
        discountPrice: "",
        quantity: "",
        unit: "pcs",
        barcode: "",
      });
    } catch {
      setError("Failed to save product.");
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (product: Product) => {
    setEditId(product.id ?? null);
    setForm({
      name: product.name,
      purchasePrice: product.purchasePrice.toString(),
      sellingPrice: product.sellingPrice.toString(),
      discountPrice: product.discountPrice?.toString() || "",
      quantity: product.quantity.toString(),
      unit: product.unit,
      barcode: product.barcode,
    });
    setView('add');
  };

  return (
    <div className="max-w-4xl mx-auto mt-8">
      <div className="flex gap-4 mb-8">
        <button
          className={`flex-1 py-3 rounded-lg shadow text-lg font-semibold transition-all duration-200 ${view === 'add' ? 'bg-gradient-to-r from-blue-600 to-purple-500 text-white shadow-lg scale-105' : 'bg-white text-blue-600 border border-blue-600 hover:bg-blue-50'}`}
          onClick={() => { setView('add'); setEditId(null); setSuccess(""); setError(""); }}
        >
          Add Product
        </button>
        <button
          className={`flex-1 py-3 rounded-lg shadow text-lg font-semibold transition-all duration-200 ${view === 'history' ? 'bg-gradient-to-r from-blue-600 to-purple-500 text-white shadow-lg scale-105' : 'bg-white text-blue-600 border border-blue-600 hover:bg-blue-50'}`}
          onClick={() => { setView('history'); setEditId(null); setSuccess(""); setError(""); }}
        >
          View Products
        </button>
      </div>
      {view === 'add' && (
        <>
          <h1 className="text-3xl font-bold mb-6 text-blue-800 flex items-center gap-2">
            {editId ? <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-base">Edit</span> : <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded text-base">Add</span>}
            Product
          </h1>
          <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-xl p-8 flex flex-col gap-5 mb-8 border border-blue-100">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input name="name" value={form.name} onChange={handleChange} placeholder="Product Name" className="border p-3 rounded-lg focus:ring-2 focus:ring-blue-200" required />
              <input name="barcode" value={form.barcode} onChange={handleChange} placeholder="Barcode Number" className="border p-3 rounded-lg focus:ring-2 focus:ring-blue-200" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <input name="purchasePrice" value={form.purchasePrice} onChange={handleChange} placeholder="Purchase Price" type="number" min="0" step="0.01" className="border p-3 rounded-lg focus:ring-2 focus:ring-blue-200" required />
              <input name="sellingPrice" value={form.sellingPrice} onChange={handleChange} placeholder="Selling Price" type="number" min="0" step="0.01" className="border p-3 rounded-lg focus:ring-2 focus:ring-blue-200" required />
              <input name="discountPrice" value={form.discountPrice} onChange={handleChange} placeholder="Discount Price" type="number" min="0" step="0.01" className="border p-3 rounded-lg focus:ring-2 focus:ring-blue-200" />
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <input name="quantity" value={form.quantity} onChange={handleChange} placeholder="Quantity" type="number" min="0" step="1" className="border p-3 rounded-lg focus:ring-2 focus:ring-blue-200" required />
              <select name="unit" value={form.unit} onChange={handleChange} className="border p-3 rounded-lg focus:ring-2 focus:ring-blue-200">
                <option value="pcs">pcs</option>
                <option value="kg">kg</option>
                <option value="litre">litre</option>
              </select>
              <button
                type="button"
                className={`flex items-center justify-center gap-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white px-4 py-3 rounded-lg font-semibold shadow hover:from-blue-600 hover:to-purple-600 transition-all ${showScanner ? 'ring-2 ring-purple-400' : ''}`}
                onClick={() => setShowScanner((v) => !v)}
              >
                {showScanner ? "Close Scanner" : "Scan Barcode"}
              </button>
            </div>
            {showScanner && (
              <div className="mb-2">
                <BarcodeScanner
                  onScan={(barcode) => setForm((prev) => ({ ...prev, barcode }))}
                  onClose={() => setShowScanner(false)}
                />
              </div>
            )}
            {error && <div className="text-red-500 text-sm font-medium">{error}</div>}
            {success && <div className="text-green-600 text-sm font-medium">{success}</div>}
            <button type="submit" className="bg-gradient-to-r from-blue-600 to-purple-500 text-white py-3 rounded-lg font-bold text-lg shadow-md hover:from-blue-700 hover:to-purple-600 transition-all disabled:opacity-50" disabled={loading}>
              {loading ? (editId ? "Updating..." : "Adding...") : editId ? "Update Product" : "Add Product"}
            </button>
          </form>
        </>
      )}
      {view === 'history' && (
        <>
          <h2 className="text-2xl font-bold mb-6 text-blue-800 flex items-center gap-2">Product History</h2>
          <div className="overflow-x-auto rounded-2xl shadow-xl border border-blue-100 bg-white">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="bg-gradient-to-r from-blue-50 to-purple-100 text-blue-700">
                  <th className="p-3 text-left font-semibold">Name</th>
                  <th className="p-3 text-left font-semibold">Purchase Price</th>
                  <th className="p-3 text-left font-semibold">Selling Price</th>
                  <th className="p-3 text-left font-semibold">Discount Price</th>
                  <th className="p-3 text-left font-semibold">Quantity</th>
                  <th className="p-3 text-left font-semibold">Unit</th>
                  <th className="p-3 text-left font-semibold">Barcode</th>
                  <th className="p-3 text-left font-semibold">Sold (History)</th>
                  <th className="p-3 text-left font-semibold">Available</th>
                  <th className="p-3 text-left font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {products.map((product) => {
                  // Calculate total sold for this product from bills
                  const sold = bills.reduce((sum, bill) =>
                    sum + (bill.items?.filter((item: BillItem) => item.id === product.id)
                      .reduce((s: number, i: BillItem) => s + (i.cartQty || 0), 0) || 0)
                  , 0);
                  const available = product.quantity - sold;
                  return (
                    <tr key={product.id} className="border-b hover:bg-blue-50 transition-colors">
                      <td className="p-3 font-medium text-gray-800">{product.name}</td>
                      <td className="p-3">₹{product.purchasePrice}</td>
                      <td className="p-3 text-blue-700 font-semibold">₹{product.sellingPrice}</td>
                      <td className="p-3 text-green-700">₹{product.discountPrice}</td>
                      <td className="p-3">{product.quantity}</td>
                      <td className="p-3 uppercase">{product.unit}</td>
                      <td className="p-3 text-xs text-gray-500">{product.barcode}</td>
                      <td className="p-3 text-xs text-gray-700">{sold}</td>
                      <td className="p-3 text-xs text-blue-700 font-bold" style={{ color: available < 50 ? '#dc2626' : undefined }}>{available}</td>
                      <td className="p-3">
                        <button onClick={() => handleEdit(product)} className="text-white bg-blue-500 hover:bg-blue-700 px-3 py-1 rounded shadow text-xs font-semibold transition-all">Edit</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
