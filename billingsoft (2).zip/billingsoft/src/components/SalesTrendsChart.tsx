import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import React from "react";

interface SalesTrendsChartProps {
  data: { date: string; total: number }[];
}

const SalesTrendsChart: React.FC<SalesTrendsChartProps> = ({ data }) => (
  <ResponsiveContainer width="100%" height={240}>
    <LineChart data={data} margin={{ top: 16, right: 24, left: 0, bottom: 0 }}>
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis
        dataKey="date"
        tick={{ fontSize: 12 }}
        angle={-30}
        textAnchor="end"
        height={50}
        minTickGap={2}
        tickFormatter={(d) => {
          // Show only day and month for clarity
          const date = new Date(d);
          if (!isNaN(date.getTime())) {
            return `${date.getDate()}/${date.getMonth() + 1}`;
          }
          return d;
        }}
      />
      <YAxis tick={{ fontSize: 12 }} tickFormatter={(v: number) => `₹${v}`} />
      <Tooltip
        formatter={(v: number) => `₹${v}`}
        labelFormatter={(d: string) => {
          // Show full date in tooltip
          const date = new Date(d);
          if (!isNaN(date.getTime())) {
            return date.toLocaleDateString();
          }
          return d;
        }}
      />
      <Line type="monotone" dataKey="total" stroke="#6366f1" strokeWidth={3} dot={{ r: 3 }} />
    </LineChart>
  </ResponsiveContainer>
);

export default SalesTrendsChart;
