"use client";

import { useEffect, useRef, useState } from "react";

export function BarcodeScanner({
  onScan,
  onClose,
}: {
  onScan: (barcode: string) => void;
  onClose?: () => void;
}) {
  const scannerId = "html5-qrcode-scanner";
  const html5QrcodeRef = useRef<import("html5-qrcode").Html5Qrcode | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let isMounted = true;

    const initScanner = async () => {
      try {
        const { Html5Qrcode } = await import("html5-qrcode");

        // Stop/clear if already exists
        if (html5QrcodeRef.current) {
          try {
            await html5QrcodeRef.current.stop();
          } catch (err: any) {
            // Suppress "not running or paused" error
            if (!String(err).includes("not running or paused")) {
              console.error("Stop error:", err);
            }
          }

          try {
            await html5QrcodeRef.current.clear();
          } catch (err) {
            console.warn("Clear error:", err);
          }
        }

        const scanner = new Html5Qrcode(scannerId);
        html5QrcodeRef.current = scanner;

        await scanner.start(
          { facingMode: "environment" },
          { fps: 10, qrbox: 300 },
          (decodedText: string) => {
            if (!isMounted) return;
            onScan(decodedText);
            scanner.stop().then(() => {
              scanner.clear();
              if (onClose) onClose();
            });
          },
          (_, error) => {
            console.warn("Scan error:", error);
          }
        );
      } catch (err: any) {
        const message = String(err);
        if (!message.includes("not running or paused")) {
          setError("Failed to start scanner: " + message);
        }
      }
    };

    initScanner();

    return () => {
      isMounted = false;
      const scanner = html5QrcodeRef.current;
      if (scanner) {
        scanner
          .stop()
          .then(() => scanner.clear())
          .catch((err: any) => {
            if (!String(err).includes("not running or paused")) {
              console.warn("Cleanup error:", err);
            }
          });
      }
    };
  }, []);

  return (
    <div>
      <style>{`
        #${scannerId} video {
          object-fit: cover !important;
          width: 100% !important;
          height: 100% !important;
          border-radius: 0.5rem;
        }
      `}</style>

      <div
        id={scannerId}
        className="mx-auto mb-4"
        style={{
          width: "100%",
          maxWidth: 360,
          height: 240,
          background: "#000",
          borderRadius: "0.5rem",
        }}
      />

      <div className="text-xs text-gray-500 text-center mb-2">
        Tip: Hold the barcode steady, ensure good lighting, and move it slowly
        in front of the camera for best results.
      </div>

      {/* Suppress error message */}
      {/* {error && (
        <div className="text-red-500 text-sm text-center">{error}</div>
      )} */}

      {onClose && (
        <button
          onClick={onClose}
          className="mt-2 px-4 py-2 bg-gray-200 rounded hover:bg-gray-300 block mx-auto"
        >
          Close Scanner
        </button>
      )}
    </div>
  );
}
