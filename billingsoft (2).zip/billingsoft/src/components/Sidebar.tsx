"use client";

// Sidebar navigation layout for the POS app
import React, { useEffect, useState } from "react";
import Link from "next/link";
import { signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { useRouter } from "next/navigation";
import DashboardIcon from "@mui/icons-material/Dashboard";
import Inventory2Icon from "@mui/icons-material/Inventory2";
import PointOfSaleIcon from "@mui/icons-material/PointOfSale";
import ReceiptLongIcon from "@mui/icons-material/ReceiptLong";
import LogoutRoundedIcon from "@mui/icons-material/LogoutRounded";

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: <DashboardIcon fontSize="medium" /> },
  { href: "/products", label: "Products", icon: <Inventory2Icon fontSize="medium" /> },
  { href: "/billing", label: "Billing", icon: <PointOfSaleIcon fontSize="medium" /> },
  { href: "/invoices", label: "Invoices", icon: <ReceiptLongIcon fontSize="medium" /> },
];

export default function Sidebar({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setIsLoggedIn(!!user);
    });
    return () => unsubscribe();
  }, []);

  const handleLogout = async () => {
    await signOut(auth);
    router.push("/auth");
  };

  return (
    <div className="flex min-h-[100dvh] max-h-[100dvh]">
      <aside className="w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 flex flex-col p-4 min-h-[100dvh] max-h-[100dvh] shadow-lg">
        <div className="flex items-center gap-2 text-2xl font-bold mb-8 tracking-tight text-gray-900 dark:text-white">
          <span className="bg-primary-100 dark:bg-primary-900 rounded-full p-2">
            <PointOfSaleIcon fontSize="large" />
          </span>
          Deepu Store
        </div>
        <nav className="flex-1 overflow-y-auto">
          <ul className="space-y-1">
            {navItems.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className="flex items-center gap-3 px-3 py-2 rounded-lg transition-colors text-gray-700 dark:text-gray-200 hover:bg-primary-50 dark:hover:bg-primary-900/40 font-medium group"
                >
                  <span className="text-primary-600 dark:text-primary-400 group-hover:scale-110 transition-transform">
                    {item.icon}
                  </span>
                  <span>{item.label}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        {isLoggedIn && (
          <button
            onClick={handleLogout}
            className="mt-8 flex items-center gap-2 bg-red-50 dark:bg-red-900 hover:bg-red-100 dark:hover:bg-red-800 text-red-700 dark:text-red-200 py-2 px-4 rounded-lg w-full font-semibold transition-colors border border-red-200 dark:border-red-800 shadow-sm"
            style={{ marginTop: "auto" }}
          >
            <LogoutRoundedIcon fontSize="small" /> Logout
          </button>
        )}
      </aside>
      <main className="flex-1 bg-gray-50 dark:bg-gray-950 p-6 overflow-y-auto min-h-[100dvh] max-h-[100dvh]">
        {children}
      </main>
    </div>
  );
}
